
public class DogTest {

	public static void main(String[] args) {
		Dog a = new Dog("�鱸 ", 1) ;
		a.print();
	    Dog b = new Dog("Ȳ��", "������" , 2);
	    b.print2() ;
	}
}
