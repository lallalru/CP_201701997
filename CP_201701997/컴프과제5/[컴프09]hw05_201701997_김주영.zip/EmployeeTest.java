
public class EmployeeTest {

	public static void main (String [] args) {
		Employee my = new Employee();
		
		my.setName("���ֿ�");
		my.setPhone("010-1234-5678");
		my.setIncome("1��");
		
		my.print();
	}
}