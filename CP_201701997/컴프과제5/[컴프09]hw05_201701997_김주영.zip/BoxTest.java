 public class BoxTest {

public static void main(String[] args) {
Box my = new Box();

my.setX(10);
my.setY(20);
my.setZ(50);

my.print();
System.out.println("���� : " + my.getVolume());

}

}