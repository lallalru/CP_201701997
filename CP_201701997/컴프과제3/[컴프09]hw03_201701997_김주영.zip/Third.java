
public class Third {

	public static void main(String[] args) {
	int i,j,k; 
	  for( i = 0; i<5; i++){
		 for( j = 0; j<4-i; j++){
		   System.out.print(" ");
		}
		 
		 for( k = 0; k < 2*i+1; k++){
		   System.out.print("*");
		}
		System.out.print("\n");
		}
	  for( i = 0; i<4; i++){
		 for( j = 0; j<i+1; j++){
		   System.out.print(" ");
		}
		 for( k = 0; k<7-2*i; k++){
		   System.out.print("*");
		}
		System.out.print("\n");
		}
		 
		}
		 
		}
		 